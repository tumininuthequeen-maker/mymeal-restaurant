# MyMeal Restaurant

A four-page website for the fictional **MyMeal Restaurant** at 88 Mott Street,
Chinatown, New York. Built with plain HTML, CSS and JavaScript — no framework,
no build step and nothing to install.

## Pages

| Page | File | What's on it |
| --- | --- | --- |
| Home | `index.html` | Editorial hero, opening marquee, story section, fan-favourite dishes, values, guest review and reservation call-to-action |
| Menu | `menu.html` | Nineteen dishes with live category filtering, dietary tags, allergen note and chef's tasting menu |
| Our story | `about.html` | Founding story, ten-year timeline, team profiles, values and photo gallery |
| Visit us | `contact.html` | Validated reservation form, address and hours, contact details, illustrated map and FAQ |

## Run locally

Any static file server works:

```bash
npx serve .
# or
python -m http.server 8080
```

Then open the printed local URL. Opening `index.html` directly also works.

## Deploy on Vercel

1. Push this folder to a GitHub repository (steps below).
2. In Vercel, choose **Add New → Project** and import the repository.
3. Keep the framework preset as **Other**. No build command or output directory
   is needed — `index.html` sits at the repository root.
4. Click **Deploy**. Every push to `main` redeploys automatically.

`vercel.json` only adds security headers; it does not change how the site is
built.

### Upload to GitHub

**Web upload:** create a new repository on GitHub, choose **uploading an
existing file**, then drag in everything from this folder — the four HTML
files and the `assets` folder. Commit.

**Command line:**

```bash
git init
git add .
git commit -m "MyMeal Restaurant website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/mymeal-restaurant.git
git push -u origin main
```

## What actually works

- **Menu filters** — All / Small plates / Mains / Pasta & bowls / Desserts /
  Drinks, with live counts, `aria-pressed` state, a screen-reader status
  message and the active filter reflected in the URL hash.
- **Reservation form** — required-field validation, email and phone checks,
  past-date blocking, inline errors, focus management and a personalised
  confirmation summary. It is a front-end demo: nothing is sent or stored.
- **Newsletter form** — email validation and a local confirmation.
- **Navigation** — sticky header, scroll state, accessible mobile drawer with
  Escape/outside-click closing and body scroll locking.
- **FAQ** — native `<details>` accordion.
- **Motion** — scroll reveals and a marquee, all disabled under
  `prefers-reduced-motion`.
- **Image fallbacks** — a warm gradient and dish emoji if a remote photo fails.

## Structure

```text
.
├─ index.html            Home
├─ menu.html             Menu + filters
├─ about.html            Story, team and gallery
├─ contact.html          Reservations, map and FAQ
├─ vercel.json           Security headers
├─ .gitignore
└─ assets/
   ├─ styles.css         Design tokens, components and responsive layout
   ├─ main.js            Nav, filters, form validation and reveals
   └─ favicon.svg
```

## Make it yours

- **Colours and type** — edit the tokens at the top of `assets/styles.css`
  (`--cream`, `--ink`, `--ember`, `--gold`, `--font-display`). Display type is
  Fraunces, body copy is Inter.
- **Menu** — each dish is a `.menu-item` with a `data-category` of `small`,
  `mains`, `pasta`, `desserts` or `drinks`. Counts and filtering update
  automatically.
- **Bookings** — the form confirms in the browser only. Point the `submit`
  handler in `assets/main.js` at a booking API or form service, and remove the
  "Demo form" note in `contact.html` when it is live.
- **Photography** — images are hot-linked from Unsplash. Swap the `src`
  attributes for your own photos and keep the surrounding `.media` frame.
- **Details** — address, phone, email, hours and social links are placeholders
  repeated in each page's header/footer and on the contact page. Update them
  together with the JSON-LD block in `index.html`.

## Notes

- Photography: [Unsplash](https://unsplash.com), free to use under the Unsplash
  licence.
- Fonts: Fraunces and Inter, loaded from Google Fonts.
- The reservation and newsletter forms intentionally do not transmit personal
  data. Add a backend, spam protection and a privacy policy before production.
- Tested in current Chrome at 390 px, 768 px, 800 px, 1024 px and 1440 px
  widths, with a 1180 px desktop container.
