/* ==========================================================================
   MyMeal Restaurant — shared interactions
   Progressive enhancement only: every page works without this file.
   ========================================================================== */
(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Image fallbacks ---------- */
  function markMissing(image) {
    var frame = image.closest(".media");
    if (!frame) return;
    if (!frame.dataset.emoji) frame.dataset.emoji = "🍽️";
    frame.classList.add("is-missing");
    image.remove();
  }

  document.querySelectorAll(".media img").forEach(function (image) {
    image.addEventListener("error", function () {
      markMissing(image);
    });
    if (image.complete && image.naturalWidth === 0) markMissing(image);
  });

  /* ---------- Sticky header ---------- */
  var header = document.querySelector(".site-header");

  function onScroll() {
    if (!header) return;
    header.classList.toggle("is-scrolled", window.scrollY > 8);
  }

  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------- Mobile navigation ---------- */
  var toggle = document.querySelector(".menu-toggle");
  var nav = document.getElementById("primary-nav");

  function closeNav() {
    if (!nav || !toggle) return;
    nav.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
    document.body.style.overflow = "";
  }

  function openNav() {
    if (!nav || !toggle) return;
    nav.classList.add("is-open");
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Close menu");
    document.body.style.overflow = "hidden";
  }

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      if (nav.classList.contains("is-open")) closeNav();
      else openNav();
    });

    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", closeNav);
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeNav();
    });

    document.addEventListener("click", function (event) {
      if (!nav.classList.contains("is-open")) return;
      if (nav.contains(event.target) || toggle.contains(event.target)) return;
      closeNav();
    });

    window.addEventListener("resize", function () {
      if (window.innerWidth > 900) closeNav();
    });
  }

  /* ---------- Scroll reveals ---------- */
  var revealItems = document.querySelectorAll("[data-reveal]");

  if (revealItems.length) {
    if (reduceMotion || !("IntersectionObserver" in window)) {
      revealItems.forEach(function (item) {
        item.classList.add("is-in");
      });
    } else {
      var revealObserver = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (!entry.isIntersecting) return;
            entry.target.classList.add("is-in");
            revealObserver.unobserve(entry.target);
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );

      revealItems.forEach(function (item) {
        revealObserver.observe(item);
      });
    }
  }

  /* ---------- Menu filters ---------- */
  var filterButtons = document.querySelectorAll(".filter-btn");
  var menuItems = document.querySelectorAll(".menu-item");
  var menuStatus = document.getElementById("menu-status");

  function applyFilter(filter) {
    var shown = 0;

    menuItems.forEach(function (item) {
      var matches = filter === "all" || item.dataset.category === filter;
      item.hidden = !matches;
      if (matches) shown += 1;
    });

    filterButtons.forEach(function (button) {
      var active = button.dataset.filter === filter;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });

    if (menuStatus) {
      menuStatus.textContent =
        "Showing " + shown + (shown === 1 ? " dish." : " dishes.");
    }
  }

  if (filterButtons.length && menuItems.length) {
    filterButtons.forEach(function (button) {
      var countNode = button.querySelector(".count");
      var filter = button.dataset.filter;
      if (!countNode) return;
      if (filter === "all") {
        countNode.textContent = menuItems.length;
      } else {
        var count = 0;
        menuItems.forEach(function (item) {
          if (item.dataset.category === filter) count += 1;
        });
        countNode.textContent = count;
      }
    });

    filterButtons.forEach(function (button) {
      button.addEventListener("click", function () {
        var filter = button.dataset.filter;
        applyFilter(filter);
        if (history.replaceState) {
          history.replaceState(
            null,
            "",
            filter === "all" ? location.pathname : "#" + filter
          );
        }
      });
    });

    var initial = location.hash.replace("#", "");
    var valid = Array.prototype.some.call(filterButtons, function (button) {
      return button.dataset.filter === initial;
    });
    if (initial && initial !== "menu" && valid) applyFilter(initial);
  }

  /* ---------- Reservation form ---------- */
  var form = document.getElementById("reservation-form");
  var card = document.querySelector(".reservation-card");

  if (form && card) {
    var dateInput = form.querySelector("#res-date");
    var success = document.querySelector(".form-success");
    var successText = document.querySelector("[data-success-summary]");
    var successName = document.querySelector("[data-success-name]");

    var today = new Date();
    var iso = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 10);
    if (dateInput) dateInput.min = iso;

    function errorFor(field) {
      return form.querySelector('[data-error-for="' + field.id + '"]');
    }

    function setError(field, message) {
      var node = errorFor(field);
      field.setAttribute("aria-invalid", "true");
      if (node) {
        node.textContent = message;
        node.classList.add("is-visible");
      }
    }

    function clearError(field) {
      var node = errorFor(field);
      field.removeAttribute("aria-invalid");
      if (node) {
        node.textContent = "";
        node.classList.remove("is-visible");
      }
    }

    form.querySelectorAll("input, select, textarea").forEach(function (field) {
      field.addEventListener("input", function () {
        clearError(field);
      });
      field.addEventListener("change", function () {
        clearError(field);
      });
    });

    function validate() {
      var firstInvalid = null;

      function fail(field, message) {
        if (!field) return;
        setError(field, message);
        if (!firstInvalid) firstInvalid = field;
      }

      var name = form.querySelector("#res-name");
      var email = form.querySelector("#res-email");
      var phone = form.querySelector("#res-phone");
      var date = form.querySelector("#res-date");
      var time = form.querySelector("#res-time");
      var guests = form.querySelector("#res-guests");

      if (!name.value.trim()) {
        fail(name, "Please tell us your name.");
      } else if (name.value.trim().length < 2) {
        fail(name, "Please enter at least two characters.");
      }

      if (!email.value.trim()) {
        fail(email, "Please add an email address.");
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim())) {
        fail(email, "That email address doesn't look right.");
      }

      if (phone.value.trim() && !/^[+()\d\s-]{7,}$/.test(phone.value.trim())) {
        fail(phone, "Please enter a valid phone number.");
      }

      if (!date.value) {
        fail(date, "Please choose a date.");
      } else if (date.value < iso) {
        fail(date, "Please choose today or a future date.");
      }

      if (!time.value) {
        fail(time, "Please choose a time.");
      }

      if (!guests.value) {
        fail(guests, "How many guests should we plan for?");
      }

      return firstInvalid;
    }

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var invalid = validate();

      if (invalid) {
        invalid.focus();
        return;
      }

      var name = form.querySelector("#res-name").value.trim();
      var dateValue = form.querySelector("#res-date").value;
      var timeValue = form.querySelector("#res-time").value;
      var guestsValue = form.querySelector("#res-guests").value;

      var dateLabel = new Date(dateValue + "T12:00:00").toLocaleDateString(
        "en-ZA",
        { weekday: "long", day: "numeric", month: "long" }
      );

      var guestLabel =
        guestsValue === "9+"
          ? "a private table for 9+ guests"
          : guestsValue + (guestsValue === "1" ? " guest" : " guests");

      if (successName) successName.textContent = name.split(" ")[0] || name;
      if (successText) {
        successText.textContent =
          guestLabel + " · " + dateLabel + " · " + timeValue;
      }

      card.classList.add("is-sent");
      if (success) {
        success.classList.add("is-visible");
        success.setAttribute("tabindex", "-1");
        success.focus();
      }
    });

    var resetButton = document.querySelector("[data-reset-booking]");
    if (resetButton) {
      resetButton.addEventListener("click", function () {
        form.reset();
        card.classList.remove("is-sent");
        if (success) {
          success.classList.remove("is-visible");
          success.removeAttribute("tabindex");
        }
        if (dateInput) dateInput.min = iso;
        var name = form.querySelector("#res-name");
        if (name) name.focus();
      });
    }
  }

  /* ---------- Newsletter ---------- */
  var newsletter = document.querySelector(".newsletter");
  if (newsletter) {
    var note = newsletter.parentElement.querySelector(".newsletter-note");
    var input = newsletter.querySelector("input");

    newsletter.addEventListener("submit", function (event) {
      event.preventDefault();
      if (!input || !note) return;

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(input.value.trim())) {
        note.textContent = "Please enter a valid email address.";
        input.focus();
        return;
      }

      note.textContent = "You're on the list — see you at the table.";
      newsletter.reset();
    });
  }

  /* ---------- FAQ: one open at a time ---------- */
  var faqs = document.querySelectorAll(".faq details");
  faqs.forEach(function (item) {
    item.addEventListener("toggle", function () {
      if (!item.open) return;
      faqs.forEach(function (other) {
        if (other !== item) other.open = false;
      });
    });
  });

  /* ---------- Footer year ---------- */
  document.querySelectorAll("[data-year]").forEach(function (node) {
    node.textContent = new Date().getFullYear();
  });
})();
